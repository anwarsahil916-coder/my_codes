number = list(range(1, 51))
sum = 0
for i in number:
    sum = sum + i
    
print("The sum of numbers from 1 to 50 is : ", sum)