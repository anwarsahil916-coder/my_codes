f_name = input("Enter your First name : ")
l_name = input("Enter your Last name : ")

full_name = f_name + " " + l_name
print("Your Full Name is : ",full_name)