org_list = [1,2,3,4,5,6,7,8,9,10]
# Extracts the first five elements from the list.
print("Extracts the first five elements : ",org_list[:5])
# Reversed extracts elements.
rev_list = org_list[:5]
rev_list.reverse()
print("Reversed extracts elements : ",rev_list)