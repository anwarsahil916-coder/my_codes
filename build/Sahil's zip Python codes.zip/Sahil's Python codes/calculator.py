a = input("Enter the first number : ")
a = int(a)
b = input("Enter the Second number : ")
b = int(b)

print("\nnAddition is : ",a+b)
print("subtraction is : ",a-b)
print("Multiplication is : ",a*b)
print("Division is : ",a/b)