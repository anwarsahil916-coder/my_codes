# stu_det = {'John' : 45,'Bob':58,'Alice': 87}
# try:
#     name = input("Enter the name of student: ")
#     if name in stu_det:
#         print("\nStudent and their marks is:", name, "-", stu_det[name])
#     else:
#         raise KeyError("Student not found.")
# except KeyError as e:
#     print(e)
# else:
#     print("\n\nStudent record found.")
from tkinter import*
import tkinter.messagebox
Window = Tk()
Window.geometry("300x250")
# n1 = input("Enter your first name : ")
# n2 = input("Enter your second name : ")

lable1 = Label(Window,text="First Name : ",)
f_name = Entry(Window,width=20,borderwidth=3)
lable2 = Label(Window,text="Last Name : ",)
l_name = Entry(Window,width=20,borderwidth=3)
res = StringVar()
msg = ""

msg = Message(Window,textvariable=res,padx=40,pady=40)
def merge():
    user_f = f_name.get()
    user_l = l_name.get()
    res.set(user_f+" " + user_l)
    

Button1 = Button(Window,text="Submit",bg="yellow",command=merge)    
lable1.grid(row = 0,column = 1)
f_name.grid(row = 0,column = 2)
lable2.grid(row = 1,column = 1)
l_name.grid(row = 1,column = 2)


Button1.grid(row=2,column=1)
msg.grid(row=2,column=2)
mainloop()