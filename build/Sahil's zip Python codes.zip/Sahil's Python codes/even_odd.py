number = int(input("Enter the number : "))

if (number % 2 == 0):
    print("The number",number,"is Even.")
else:
    print("The number ",number," is Odd.") 